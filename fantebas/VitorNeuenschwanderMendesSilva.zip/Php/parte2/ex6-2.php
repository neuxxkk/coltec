<?php
echo "
<html>
    <head>
        <title>Alemao</title>
    </heaad>
    <body>
        <h2 style = 'color:red;'>Hello, world!</h2>
    </body>
</html>
"
?>
