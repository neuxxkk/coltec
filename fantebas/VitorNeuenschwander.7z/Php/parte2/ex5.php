<html>
  <head>
    <title>Alemao</title>
  </head>
  <body>
    <table>
        <tr>
          <th><?php echo "Nome"; ?></th>
          <th><?php echo "Idade"; ?></th>
        </tr>
        <tr>
          <td><?php echo "Vitor"; ?></td>
          <td><?php echo "16"; ?></td>
        </tr>
    </table>
  </body>

  <style>
    table, th, td {
      border: 1px solid black;
      border-collapse: collapse;
    }
  </style>

</html>
